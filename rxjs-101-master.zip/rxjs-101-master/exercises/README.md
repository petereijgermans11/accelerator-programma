## Exercises

1. [Range observable](exercise_1.html)
2. [Filter values with operators](exercise_2.html)
3. [Transforming values with operators](exercise_2.html)
4. [Combining multiple operators](exercise_4.html)

5. [Refactoring Subjects](exercise_5.html)
6. [Error handling](exercise_6.html)
7. [Make complex things simple](exercise_7.html)
8. [Combining and filtering streams](exercise_8.html)


Bonusses
- [Text input](exercise_%3F.html)
