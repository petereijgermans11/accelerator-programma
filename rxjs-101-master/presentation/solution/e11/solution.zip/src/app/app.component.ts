import { Component, OnInit } from '@angular/core';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators'

type item = { name: string };

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit  {
  name = 'Angular';
  items$: Observable<item[]>
  cache: item[] = []

  ngOnInit() {
    this.items$ = this.getItems()
  }

  refreshFromCache(): Observable<item[]> {
    console.count('retrieving from local cache')
    return of(this.cache)
  }

  refresh() {
    this.items$ = this.getItems();
  }

  addItem(item: item) {
    const prevData = this.cache;
    const nextData = [ ...prevData, item ];
    this.cache = nextData

    //if ur api fails return to previous state (show feedback to user there was issue)
    this.postItem(item).subscribe({ error: (err) => this.cache = prevData})
    this.items$ = this.refreshFromCache()
  }

  getItems(): Observable<item[]> {
    // do your api call
    console.count('calling API!')
    return of([{ name: 'something' }, { name: 'another something' }]).pipe(
      tap( () => { console.log('Retrieving from the Server') }),
      tap(data => this.cache = data)
    )
  }

  postItem(item: item) {
    // do your api call
    return of();
  }
}
