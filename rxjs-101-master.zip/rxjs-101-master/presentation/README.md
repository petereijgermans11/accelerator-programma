## Presentation
`cd ../`

Installation:
`npm install`

Run presenation
`npm run reveal`

Export presentation to static HTML in `./docs` directory
`npm run reveal-export`
